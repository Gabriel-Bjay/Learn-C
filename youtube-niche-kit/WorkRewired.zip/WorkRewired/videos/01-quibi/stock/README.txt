Stock clips are downloaded here automatically (Pixabay key).
Or save clips by hand using the file names the preview run tells you.
