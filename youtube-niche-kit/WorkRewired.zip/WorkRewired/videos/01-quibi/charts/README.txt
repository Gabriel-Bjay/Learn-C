Put the chart images here, using the exact file names from shots.txt.
