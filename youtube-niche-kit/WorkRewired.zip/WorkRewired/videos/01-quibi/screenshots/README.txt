Save screenshots here (Win + Shift + S, paste into Paint, save as .png)
using the exact file names from shots.txt.
